#include "ros/ros.h"
#include "hw5/NavPR.h"
#include <move_base_msgs/MoveBaseAction.h>



    NavPR::NavPR(tf::TransformListener &tfL, MoveBaseClient &ac) : _tfL(tfL), _ac(ac){

    }

    void NavPR::receivePose(geometry_msgs::Pose &pose) {
      Eigen::Vector3d vec(pose.position.x, 0, pose.position.z); // location of marker
     // Eigen::Vector3d corner(0, 0, pose.position.z);
      vec /= vec.norm();
      //corner /= corner.norm();
      double angleInRadians = atan2(vec(0), vec(2));
      move_base_msgs::MoveBaseGoal goal;

      goal.target_pose.header.frame_id = "base_link";
      goal.target_pose.header.stamp = ros::Time::now();

      //goal.target_pose.pose.position.x = 0.25*vec(2);
      goal.target_pose.pose.position.x = 0.25 *vec(2);
      goal.target_pose.pose.position.y = 0;
      goal.target_pose.pose.position.z = 0;
      // tf::Quaternion q(0,0,angleInRadians,1);
      
      goal.target_pose.pose.orientation.x = 0;
      goal.target_pose.pose.orientation.y = 0;
      goal.target_pose.pose.orientation.z = angleInRadians*-0.5;
      goal.target_pose.pose.orientation.w = 1;

      if(vec(2) > 0.25){
     	 ROS_INFO("Sending goal");
      	_ac.sendGoal(goal);

     	_ac.waitForResult();
   	if(_ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
       	ROS_INFO("Hooray, the base moved");
    	else
       	ROS_INFO("The base failed to move forward");  
      }
   }
