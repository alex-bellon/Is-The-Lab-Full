#include "ros/ros.h"
#include "hw5/TFBroadcastPR.h"




    TFBroadcastPR::TFBroadcastPR(std::string toFrame, std::string fromFrame, tf::TransformBroadcaster &pr){
        _toFrame=toFrame;
        _fromFrame=fromFrame;
        br = pr;
    }

    void TFBroadcastPR::receivePose(geometry_msgs::Pose &pose) {
      tf::Transform transform;
      // transform.setOrigin(0,0,0);//idk but might have to change This
      tf::Vector3 origin(pose.position.x, pose.position.y, pose.position.z);
      transform.setOrigin(origin);
      tf::Quaternion q(pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w);
      transform.setRotation(q);
      br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), _toFrame, _fromFrame));
    }
