#include "ros/ros.h"
#include "hw5/OffsetFlipPR.h"
#include "tf/transform_datatypes.h"
#include "Eigen/Core"
#include "Eigen/Geometry"
#include "tf/tf.h"



    OffsetFlipPR::OffsetFlipPR(double x, double y, double z, PoseRecipient &pr): pr(pr){
        _x=x;
        _y=y;
        _z=z;
        // pr = pr;

    }

    void OffsetFlipPR::receivePose(geometry_msgs::Pose &pose) {
      tf::Transform transform;
      // transform.setOrigin(0,0,0);//idk but might have to change This
      // tf::Vector3 origin(pose.position.x + x, pose.position.y + y, pose.position.z + z);
      // Eigen::MatrixXd p(3,1);rFlip(
      // p(0,0) = pose.position.x;
      // p(0,1) = pose.position.y;
      // p(0,2) = pose.position.z;

      Eigen::Quaterniond p(pose.orientation.w,pose.orientation.x,pose.orientation.y, pose.orientation.z);
      // Eigen::Quaterniond q(pose.orientation.w, pose.orientation.x + pose.orientation.r, pose.orientation.y + pose.orientation.p, pose.orientation.z + pose.orientation.y);
      // Eigen::Quaterniond q(0,_x*3.14159,_y*3.14159,_z*3.14159);
            Eigen::Quaterniond q(0,_x,_y,_z);

      Eigen::Quaterniond rotatedP = q * p;
      rotatedP.normalize();
      // transform.setOrigin(origin);
      // tf::Quaternion q(pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w);
      // transform.setRotation(q);
      geometry_msgs::Pose newPose;
      newPose.position.x = pose.position.x;
      newPose.position.y = pose.position.y;
      newPose.position.z = pose.position.z;
      newPose.orientation.x = rotatedP.x();
      newPose.orientation.y = rotatedP.y();
      newPose.orientation.z = rotatedP.z();
      newPose.orientation.w = rotatedP.w();

      pr.receivePose(newPose);
    }
