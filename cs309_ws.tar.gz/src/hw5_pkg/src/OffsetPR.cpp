#include "ros/ros.h"
#include "hw5/OffsetPR.h"
#include "Eigen/Core"
#include "Eigen/Geometry"



    OffsetPR::OffsetPR(double x, double y, double z, PoseRecipient &pr): pr(pr){
        _x=x;
        _y=y;
        _z=z;
        // pr = pr;

    }

    void OffsetPR::receivePose(geometry_msgs::Pose &pose) {
      // transform.setOrigin(0,0,0);//idk but might have to change This
      // tf::Vector3 origin(pose.position.x + x, pose.position.y + y, pose.position.z + z);


      Eigen::MatrixXd p(1,3);
      p(0,0) = pose.position.x;
      p(0,1) = pose.position.y;
      p(0,2) = pose.position.z;

      Eigen::MatrixXd t(1,3);
      t(0,0) = _x;
      t(0,1) = _y;
      t(0,2) = _z;

      Eigen::MatrixXd result(1,3);
      // result(0,0) = p(0,0) + t(0,0);
      // result(0,1) = p(0,1) + t(0,1);
      // result(0,2) = p(0,2) + t(0,2);
      result = p-t;

      // transform.setOrigin(origin);
      // tf::Quaternion q(pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w);
      // transform.setRotation(q);
      geometry_msgs::Pose newPose;
      newPose.position.x = result(0,0);
      newPose.position.y = result(0,1);
      newPose.position.z = result(0,2);
      newPose.orientation.w = pose.orientation.w;
      newPose.orientation.x = pose.orientation.x;
      newPose.orientation.y = pose.orientation.y;
      newPose.orientation.z = pose.orientation.z;

      pr.receivePose(newPose);
    }
