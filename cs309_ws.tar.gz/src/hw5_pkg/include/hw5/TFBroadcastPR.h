#ifndef TF_BROADCAST
#define TF_BROADCAST

#include "PoseRecipient.h"

#include <tf/tf.h>
#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>



class TFBroadcastPR : public PoseRecipient {
public:

  TFBroadcastPR(std::string toFrame, std::string fromFrame,tf::TransformBroadcaster &br);


  void receivePose(geometry_msgs::Pose &pose);
private:
  tf::TransformBroadcaster br; 
  std::string _toFrame;
  std::string _fromFrame;
};

#endif
