#ifndef OFFSET_PR_FLIP
#define OFFSET_PR_FLIP

#include "PoseRecipient.h"

#include <tf/tf.h>
#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>



class OffsetFlipPR : public PoseRecipient {
public:

  OffsetFlipPR(double x, double y, double z, PoseRecipient &pr);


  void receivePose(geometry_msgs::Pose &pose);
protected:
  double _x;
  double _y;
  double _z;
  PoseRecipient &pr;
};

#endif
