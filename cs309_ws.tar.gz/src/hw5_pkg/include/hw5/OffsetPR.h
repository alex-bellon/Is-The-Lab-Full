#ifndef OFFSET_PR
#define OFFSET_PR

#include "PoseRecipient.h"

#include <tf/tf.h>
#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>



class OffsetPR : public PoseRecipient {
public:

  OffsetPR(double x, double y, double z, PoseRecipient &pr);


  void receivePose(geometry_msgs::Pose &pose);
private:
  double _x;
  double _y;
  double _z;
  PoseRecipient &pr;
};

#endif
